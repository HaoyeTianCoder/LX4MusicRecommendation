
#from
original_file = 'D:/kaggle/kaggle_visible_evaluation_triplets-source.txt'
train_v = 'D:/kaggle/train_v3.txt'
unique_tracks = 'D:/kaggle/unique_tracks.txt'
track_info_dir = 'D:/kaggle/track_info'
song_track_txt = 'D:/kaggle/taste_profile_song_to_tracks.txt'
track_year_txt =  'D:/kaggle/tracks_per_year.txt'

#to
song_popularity = 'D:/kaggle/song_popularity.json'
song_artist = 'D:/kaggle/song_artist.json'
user_like = 'D:/kaggle/user_like.json'
song_year = 'D:/kaggle/song_year.json'
song_track = 'D:/kaggle/song_track.json'
track_info1 = 'D:/kaggle/track_info1.json'
track_info2 = 'D:/kaggle/track_info2.json'
track_info3 = 'D:/kaggle/track_info3.json'
track_year = 'D:/kaggle/track_year.json'
hdf5_file = 'D:/kaggle/subset_msd_summary_file.h5'
track_list = 'D:/kaggle/track_list.json'
genre_dir = 'D:/kaggle/track_info'
user_like_genre = 'D:/kaggle/user_like_genre.json'
song_genre = 'D:/kaggle/song_genre.json'